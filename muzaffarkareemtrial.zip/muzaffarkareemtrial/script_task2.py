import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import seaborn as sns


data=pd.read_csv("dubai_properties.csv")
data.dropna(inplace=True)

average_rent_by_type = data.groupby('Type')['Rent'].mean()
print(average_rent_by_type)


average_rent_by_furnishing = data.groupby('Furnishing')['Rent'].mean()
print(average_rent_by_furnishing)




city_distribution = data['City'].value_counts().reset_index()
city_distribution.columns = ['City', 'Number of Properties']

plt.figure(figsize=(10, 6))
plt.bar(city_distribution['City'], city_distribution['Number of Properties'], color='blue')
plt.title('Rental Property Distribution by City')
plt.xlabel('City')
plt.ylabel('Number of Properties')
plt.xticks(rotation=90)  # Rotate x-axis labels for better visibility
plt.tight_layout()  # Adjust layout to prevent clipping of labels
plt.show()

# # Identify trends over time if time series data is available
# # Example: Assuming 'date' column exists
# merged_data['date'] = pd.to_datetime(merged_data['date'])
# time_series_data = merged_data.set_index('date').resample('M').mean()

# # Step 4: Visualize Results
# plt.figure(figsize=(15, 10))

# # Heatmap for correlation matrix
# plt.subplot(2, 2, 1)
# sns.heatmap(correlation_matrix, annot=True, cmap='coolwarm')
# plt.title('Correlation Matrix')

# # Line plot for time series trends
# plt.subplot(2, 2, 2)
# for column in time_series_data.columns:
#     plt.plot(time_series_data.index, time_series_data[column], label=column)
# plt.legend()
# plt.title('Time Series Trends')

# # Scatter plot for a pair of variables
# plt.subplot(2, 2, 3)
# sns.scatterplot(x='variable1', y='variable2', data=merged_data)
# plt.title('Scatter Plot of Variable1 vs Variable2')

# # Histogram for a single variable
# plt.subplot(2, 2, 4)
# sns.histplot(merged_data['variable1'], bins=30, kde=True)
# plt.title('Histogram of Variable1')

# plt.tight_layout()
# plt.show()